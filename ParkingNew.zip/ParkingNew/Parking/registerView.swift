//
//  registerView.swift
//  Parking
//
//  Created by Randy Lina on 2/14/17.
//  Copyright © 2017 Ralph Lina. All rights reserved.
//

import Foundation
